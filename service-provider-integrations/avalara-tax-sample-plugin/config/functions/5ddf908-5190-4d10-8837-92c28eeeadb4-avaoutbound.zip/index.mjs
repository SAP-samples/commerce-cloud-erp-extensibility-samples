/*
 * Copyright: 2025 SAP SE or an SAP affiliate company
 * License: Apache-2.0
 */
export const handler = (input) => {
    const { orderId, type, customerId, orderedAt, currencyCode, items, addresses, commit } = input.data;

    const formatCurrentDate = function () {
        var d = new Date(),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [month, day, year].join('/') + " 00:00:00";
    }
    const currentDate = type === "SALES_ORDER" || type === "SALES_INVOICE" || type === "RETURN_INVOICE" ? formatCurrentDate() : "1971-01-01";
    const targetResult =
    {
        code: orderId,
        customerCode: customerId,
        currencyCode: currencyCode,
        commit: commit,
        date: currentDate,
        lines: items.map(item => ({
            number: item.id,
            quantity: item.quantity,
            amount: item.subTotal,
            itemCode: item.productId
        })),
        addresses: {
            singleLocation: addresses.filter(addr => addr.type === "SHIP_TO").map(addr => ({
                region: addr.regionCode,
                country: addr.countryCode,
                postalCode: addr.postalCode,
                line1: addr.addressLine1,
                line2: addr.addressLine2
            }))[0]
        }
    };

    return targetResult;
}
