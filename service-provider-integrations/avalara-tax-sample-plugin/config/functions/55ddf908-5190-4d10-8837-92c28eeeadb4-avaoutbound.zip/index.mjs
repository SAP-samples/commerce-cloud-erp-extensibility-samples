export const handler = (input) => {
    const { cartId, type, customerId, simulatedAt, currencyCode, items, addresses } = input.data;

    const formatCurrentDate = function () {
        var d = new Date(),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [month, day, year].join('/') + " 00:00:00";
    }
    const currentDate = type === "SALES_ORDER" || type === "SALES_INVOICE" || type === "RETURN_INVOICE" ? formatCurrentDate() : "1971-01-01";
    const targetResult =
    {
        code: cartId,
        customerCode: customerId,
        currencyCode: currencyCode,
        date: currentDate,
        lines: items.map(item => ({
            number: item.id,
            quantity: item.quantity,
            amount: item.subTotal,
            itemCode: item.productId
        })),
        addresses: {
            shipTo: addresses.filter(addr => addr.type === "SHIP_TO").map(addr => ({
                region: addr.regionCode,
                country: addr.countryCode,
                postalCode: addr.postalCode,
                line1: addr.addressLine1,
                line2: addr.addressLine2
            }))[0]
        }
    };

    return targetResult;
}
