// Included in each standalone function ZIP. Bound the final serialized record,
// not just its array samples: escaped message text can also grow a log line.
const MAX_LOG_JSON_CHARS = 2048;
const MAX_PRODUCT_SAMPLES = 5;
const MAX_ISSUE_SAMPLES = 5;
const MAX_MESSAGE_SAMPLES = 3;
const MAX_MESSAGE_TEXT_CHARS = 160;
const MAX_DEBUG_JSON_CHARS = 21000;
const MAX_DEBUG_PRODUCT_SAMPLES = 100;
const MAX_DEBUG_ISSUE_SAMPLES = 20;
const MAX_BASE_PRICE_CANDIDATES = 3;
const PRICING_LOG_MODE_KEY = 'pricing.logging.mode';
const PRICING_CONTEXT_FIELDS = [
    ['SalesOrganization', 'salesOrganization'], ['DistributionChannel', 'distributionChannel'],
    ['Division', 'division'], ['TransactionCurrency', 'currency'],
    ['PricingDate', 'pricingDate'], ['SoldToParty', 'soldToParty'],
];

function mappingDebugEnabled(input, configuration) {
    if (!configuration || typeof configuration !== 'object' || Array.isArray(configuration)) return false;
    const store = typeof input?.commerceContext?.storeId === 'string' ? input.commerceContext.storeId.trim() : '';
    const mode = (store ? configuration[store + '.' + PRICING_LOG_MODE_KEY] : undefined)
        ?? configuration[PRICING_LOG_MODE_KEY];
    return typeof mode === 'string' && mode.trim().toLowerCase() === 'debug';
}

function logScalar(value, limit = 48) {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'boolean') return value;
    return value == null ? null : logText(value, limit);
}

function pricingContextDiffers(item, first) {
    return PRICING_CONTEXT_FIELDS.some(pair => item[pair[0]] !== first?.[pair[0]]);
}

function logMappingProduct(mapping, first) {
    // Use the mapping's selected candidates and calculated prices.
    const { item, candidates, productPrice } = mapping;
    const elements = Array.isArray(item._SalesPriceElements) ? item._SalesPriceElements : [];
    const product = {
        id: logText(item.Product),
        quantity: logScalar(item.RequestedQuantity),
        unit: { code: logText(item.RequestedQuantitySAPUnit, 16), isoCode: logText(item.RequestedQuantityISOUnit, 16) },
        netAmount: logScalar(item.NetAmount),
        netPriceAmount: logScalar(item.NetPriceAmount),
        netPriceQuantity: logScalar(item.NetPriceQuantity),
        netPriceUnit: { code: logText(item.NetPriceQuantityUnitSAPCode, 16), isoCode: logText(item.NetPriceQuantityUnitISOCode, 16) },
        pricingHasError: item.PricingHasError === true,
        mapped: productPrice !== null,
        priceElementCount: elements.length,
        effectiveValue: productPrice?.price.effectiveValue ?? null,
        priceUnit: productPrice ? { code: logText(productPrice.salesMeasureUnit.code, 16), isoCode: logText(productPrice.salesMeasureUnit.isoCode, 16) } : null,
        basePriceAmount: productPrice?.price.priceBreakdowns[0].amount ?? null,
        basePriceCandidateCount: candidates.length,
        basePriceCandidates: candidates.slice(0, MAX_BASE_PRICE_CANDIDATES).map(element => ({
            counter: logScalar(element.PricingProcedureCounter, 16),
            amount: logScalar(element.ConditionAmount),
            amountCurrency: logText(element.TransactionCurrency, 8),
            baseQuantity: logScalar(element.ConditionBaseQuantity),
            rateAmount: logScalar(element.ConditionRateAmount),
            priceQuantity: logScalar(element.ConditionQuantity),
            unit: { code: logText(element.ConditionQuantityUnitSAPCode, 16), isoCode: logText(element.ConditionQuantityUnitISOCode, 16) },
            rateCurrency: logText(element.ConditionCurrency, 8),
            description: logText(element.PriceElementDescription),
        })),
        basePriceCandidatesOmitted: Math.max(0, candidates.length - MAX_BASE_PRICE_CANDIDATES),
    };
    if (pricingContextDiffers(item, first)) {
        product.contextOverrides = {};
        for (const pair of PRICING_CONTEXT_FIELDS) {
            if (item[pair[0]] !== first?.[pair[0]]) product.contextOverrides[pair[1]] = logScalar(item[pair[0]]);
        }
    }
    return product;
}

function logText(value, limit = 48) {
    if (!['string', 'number', 'boolean'].includes(typeof value)) return '';
    const text = String(value).slice(0, limit);
    let cleaned = '';
    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        cleaned += code < 32 || code === 127 ? ' ' : text[index];
    }
    return cleaned;
}

function logSystemMessage(message) {
    const text = message?.SystemMessageText;
    return {
        type: logText(message?.SystemMessageType, 8),
        class: logText(message?.SystemMessageIdentification),
        number: logText(message?.SystemMessageNumber, 16),
        text: logText(text, MAX_MESSAGE_TEXT_CHARS),
        textTruncated: typeof text === 'string' && text.length > MAX_MESSAGE_TEXT_CHARS,
    };
}

function logPricingSummary(name, summary, maxChars = MAX_LOG_JSON_CHARS) {
    let serialized = JSON.stringify(summary);
    while (serialized.length > maxChars) {
        if (summary.logMode === 'debug') summary.detailsTruncated = true;
        // Keep provider issues ahead of successful/requested product samples.
        if (summary.products.length > 0) {
            summary.products.pop();
            summary.productsOmitted++;
        } else {
            let issue;
            for (let index = summary.issues.length - 1; index >= 0; index--) {
                if (summary.issues[index].messages.length > 1) {
                    issue = summary.issues[index];
                    break;
                }
            }
            if (issue) {
                issue.messages.pop();
                issue.messagesOmitted++;
            } else if (summary.issues.length > 0) {
                summary.issues.pop();
                summary.issuesOmitted++;
            } else {
                // All fields above are bounded, but preserve counts if future
                // additions accidentally exceed the record budget.
                serialized = JSON.stringify({
                    productCount: summary.productCount,
                    mappedProducts: summary.mappedProducts,
                    skippedProducts: summary.skippedProducts,
                    issueProductCount: summary.issueProductCount,
                    systemMessageCount: summary.systemMessageCount,
                    detailsOmitted: true,
                });
                break;
            }
        }
        serialized = JSON.stringify(summary);
    }
    // Diagnostic: <8 KiB. Opt-in debug: <64 KiB. One call in either mode.
    console.log('[' + name + '] ' + serialized);
}

function logPricingContext(input, first) {
    return {
        storeId: logText(input?.commerceContext?.storeId),
        extensionId: logText(input?.extensibilityContext?.id),
        salesOrganization: logText(first?.SalesOrganization, 16),
        distributionChannel: logText(first?.DistributionChannel, 16),
        division: logText(first?.Division, 16),
        currency: logText(first?.TransactionCurrency, 8),
        pricingDate: logText(first?.PricingDate, 32),
    };
}

function logInboundPricing(input, items, mappings, configuration) {
    const debug = mappingDebugEnabled(input, configuration);
    const productLimit = debug ? MAX_DEBUG_PRODUCT_SAMPLES : MAX_PRODUCT_SAMPLES;
    const issueLimit = debug ? MAX_DEBUG_ISSUE_SAMPLES : MAX_ISSUE_SAMPLES;
    const summary = {
        ...logPricingContext(input, items[0]),
        productCount: items.length,
        mappedProducts: mappings.filter(mapping => mapping.productPrice !== null).length,
        skippedProducts: mappings.filter(mapping => mapping.productPrice === null).length,
        issueProductCount: 0,
        systemMessageCount: 0,
        skipReasonCounts: { systemMessages: 0, noPriceElements: 0, nonPositiveNetAmount: 0,
            invalidRequestedQuantity: 0, missingRequestedUnit: 0, invalidNetAmount: 0,
            missingBasePriceElement: 0, invalidBaseAmount: 0, priceCurrencyMismatch: 0 },
        products: debug
            ? mappings.slice(0, productLimit).map(mapping => logMappingProduct(mapping, items[0]))
            : items.slice(0, productLimit).map(item => ({ id: logText(item.Product) })),
        productsOmitted: Math.max(0, items.length - productLimit),
        issues: [],
        issuesOmitted: 0,
    };
    if (debug) {
        summary.logMode = 'debug';
        summary.mappingBasis = 'requestedQuantityTotals';
        summary.soldToParty = logText(items[0]?.SoldToParty);
        summary.basePriceSelection = 'firstEmptyConditionTypeByCounter';
        summary.contextMismatchProducts = items.filter(item => pricingContextDiffers(item, items[0])).length;
        summary.detailsTruncated = summary.productsOmitted > 0
            || summary.products.some(product => product.basePriceCandidatesOmitted > 0);
    }
    for (const { item, skipReasons: reasons } of mappings) {
        const messages = Array.isArray(item._SystemMessages) ? item._SystemMessages : [];
        summary.systemMessageCount += messages.length;
        for (const reason of reasons) summary.skipReasonCounts[reason]++;
        if (reasons.length === 0 && item.PricingHasError !== true) continue;
        summary.issueProductCount++;
        if (summary.issues.length >= issueLimit) {
            summary.issuesOmitted++;
            continue;
        }
        summary.issues.push({
            productId: logText(item.Product),
            pricingHasError: item.PricingHasError === true,
            skipped: reasons.length > 0,
            skipReasons: reasons,
            messageCount: messages.length,
            messages: messages.slice(0, MAX_MESSAGE_SAMPLES).map(logSystemMessage),
            messagesOmitted: Math.max(0, messages.length - MAX_MESSAGE_SAMPLES),
        });
    }
    const providerError = input?.data?.error;
    if (providerError) {
        const text = typeof providerError.message === 'string' ? providerError.message : providerError.message?.value;
        summary.providerError = { code: logText(providerError.code), text: logText(text, MAX_MESSAGE_TEXT_CHARS),
            textTruncated: typeof text === 'string' && text.length > MAX_MESSAGE_TEXT_CHARS };
    }
    if (debug) summary.detailsTruncated = summary.detailsTruncated || summary.issuesOmitted > 0
        || summary.issues.some(issue => issue.messagesOmitted > 0 || issue.messages.some(message => message.textTruncated));
    logPricingSummary('s4salespriceInbound', summary, debug ? MAX_DEBUG_JSON_CHARS : MAX_LOG_JSON_CHARS);
}

function logOutboundPricing(input, products, result, configuration) {
    const debug = mappingDebugEnabled(input, configuration);
    const productLimit = debug ? MAX_DEBUG_PRODUCT_SAMPLES : MAX_PRODUCT_SAMPLES;
    const summary = {
        ...logPricingContext(input, result),
        productCount: products.length,
        hasSoldToParty: Boolean(result._SoldToParty?.[0]?.SoldToParty),
        products: products.slice(0, productLimit).map(product => ({
            id: logText(product.id),
            quantity: debug ? logScalar(product.quantity, 16) : logText(product.quantity, 16),
            unit: logText(product.salesMeasureUnit?.code, 16),
            isoUnit: logText(product.salesMeasureUnit?.isoCode, 16),
            ...(debug ? { quantityIncluded: product.quantity != null } : {}),
        })),
        productsOmitted: Math.max(0, products.length - productLimit),
        issues: [],
        issuesOmitted: 0,
    };
    if (debug) {
        summary.logMode = 'debug';
        summary.soldToParty = logText(result._SoldToParty?.[0]?.SoldToParty);
        summary.soldToPartySource = input?.data?.soldToParty ? 'request' : summary.hasSoldToParty ? 'configuration' : 'empty';
        summary.currencySource = input?.data?.currency?.sapCode != null ? 'sapCode' : input?.data?.currency?.code != null ? 'code' : 'empty';
        summary.pricingDateSource = input?.data?.pricingAt ? 'pricingAt' : 'currentDate';
        summary.detailsTruncated = summary.productsOmitted > 0;
    }
    logPricingSummary('s4salespriceOutbound', summary, debug ? MAX_DEBUG_JSON_CHARS : MAX_LOG_JSON_CHARS);
}

function pricingNumber(value) {
    // OData decimals can be numbers or numeric strings. Avoid coercing null,
    // booleans, empty text or non-decimal strings into usable pricing data.
    if (typeof value === 'string') {
        const text = value.trim();
        if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(text)) return NaN;
        value = Number(text);
    }
    return typeof value === 'number' && Number.isFinite(value) ? value : NaN;
}

function unitCode(value) {
    return typeof value === 'string' ? value.trim() : '';
}

function mapPricingProduct(item, currency) {
    const elements = Array.isArray(item._SalesPriceElements) ? item._SalesPriceElements : [];
    const candidates = elements.slice()
        .sort((a, b) => Number(a.PricingProcedureCounter) - Number(b.PricingProcedureCounter))
        .filter(element => element.ConditionType === '');
    const mapping = { item, candidates, skipReasons: [], productPrice: null };
    const reasons = mapping.skipReasons;
    // Preserve the existing provider-message and eligibility rules.
    if (item._SystemMessages?.length > 0) reasons.push('systemMessages');
    if (elements.length === 0) reasons.push('noPriceElements');
    if (reasons.length > 0) return mapping;

    const quantity = pricingNumber(item.RequestedQuantity);
    if (!(quantity > 0)) reasons.push('invalidRequestedQuantity');
    const netAmount = pricingNumber(item.NetAmount);
    if (!Number.isFinite(netAmount)) reasons.push('invalidNetAmount');
    else if (!(netAmount > 0)) reasons.push('nonPositiveNetAmount');
    const requestedUnit = { code: unitCode(item.RequestedQuantitySAPUnit), isoCode: unitCode(item.RequestedQuantityISOUnit) };
    // The SPI requires its salesMeasureUnit.code. Never substitute an ISO code
    // for a missing SAP code or infer a unit from the native rate fields.
    if (!requestedUnit.code) reasons.push('missingRequestedUnit');

    const basePrice = candidates[0];
    const baseTotal = basePrice ? pricingNumber(basePrice.ConditionAmount) : NaN;
    if (!basePrice) {
        reasons.push('missingBasePriceElement');
    } else if (!(baseTotal >= 0)) reasons.push('invalidBaseAmount');
    // ConditionAmount is in TransactionCurrency. ConditionCurrency describes
    // the native rate and can legitimately differ from the total's currency.
    if (!currency || item.TransactionCurrency !== currency || (basePrice && basePrice.TransactionCurrency !== currency)) {
        reasons.push('priceCurrencyMismatch');
    }
    if (reasons.length > 0) return mapping;

    // S/4 totals cover this requested quantity, including any unit conversion
    // already performed by the provider. No native-rate conversion or fallback.
    const effectiveValue = netAmount / quantity;
    const baseAmount = baseTotal / quantity;
    if (!Number.isFinite(effectiveValue)) reasons.push('invalidNetAmount');
    if (!Number.isFinite(baseAmount)) reasons.push('invalidBaseAmount');
    if (reasons.length > 0) return mapping;
    mapping.productPrice = {
        id: item.Product,
        salesMeasureUnit: requestedUnit,
        quantity,
        soldToParty: item.SoldToParty ?? '',
        price: {
            // Retain division precision; currency/display rounding is downstream.
            effectiveValue,
            priceBreakdowns: [{ type: 'BASE_PRICE', amount: baseAmount }],
            scalePrices: [],
        },
    };
    return mapping;
}

export const handler = (input, configuration) => {
    const items = input?.data?.value ?? [];
    const first = items[0] ?? {};
    const mappings = items.map(item => mapPricingProduct(item, first.TransactionCurrency));
    const result = {
        data: {
            operations: [{
                operationId: 'determinePrices',
                data: {
                    salesArea: {
                        salesOrganization: first.SalesOrganization ?? '',
                        distributionChannel: first.DistributionChannel ?? '',
                        division: first.Division ?? '',
                    },
                    currency: { sapCode: first.TransactionCurrency ?? '', code: first.TransactionCurrency ?? '' },
                    productPrices: mappings.filter(mapping => mapping.productPrice !== null).map(mapping => mapping.productPrice),
                },
            }],
        },
    };
    logInboundPricing(input, items, mappings, configuration);
    return result;
};
