// Included in each standalone function ZIP. Bound the final serialized record,
// not just its array samples: escaped message text can also grow a log line.
const MAX_LOG_JSON_CHARS = 2048;
const MAX_PRODUCT_SAMPLES = 5;
const MAX_ISSUE_SAMPLES = 5;
const MAX_MESSAGE_SAMPLES = 3;
const MAX_MESSAGE_TEXT_CHARS = 160;
const MAX_DEBUG_JSON_CHARS = 21000;
const MAX_DEBUG_PRODUCT_SAMPLES = 100;
const MAX_DEBUG_ISSUE_SAMPLES = 20;
const MAX_BASE_PRICE_CANDIDATES = 3;
const PRICING_LOG_MODE_KEY = 'pricing.logging.mode';
const PRICING_CONTEXT_FIELDS = [
    ['SalesOrganization', 'salesOrganization'], ['DistributionChannel', 'distributionChannel'],
    ['Division', 'division'], ['TransactionCurrency', 'currency'],
    ['PricingDate', 'pricingDate'], ['SoldToParty', 'soldToParty'],
];

function mappingDebugEnabled(input, configuration) {
    if (!configuration || typeof configuration !== 'object' || Array.isArray(configuration)) return false;
    const store = typeof input?.commerceContext?.storeId === 'string' ? input.commerceContext.storeId.trim() : '';
    const mode = (store ? configuration[store + '.' + PRICING_LOG_MODE_KEY] : undefined)
        ?? configuration[PRICING_LOG_MODE_KEY];
    return typeof mode === 'string' && mode.trim().toLowerCase() === 'debug';
}

function logScalar(value, limit = 48) {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'boolean') return value;
    return value == null ? null : logText(value, limit);
}

function pricingContextDiffers(item, first) {
    return PRICING_CONTEXT_FIELDS.some(pair => item[pair[0]] !== first?.[pair[0]]);
}

function logMappingProduct(item, first, mapped) {
    // Match the mapper: sort the complete array before selecting empty types.
    // Never serialize entire elements or non-mapping fields.
    const elements = Array.isArray(item._SalesPriceElements) ? item._SalesPriceElements : [];
    const candidates = elements.slice().sort((a, b) => Number(a.PricingProcedureCounter) - Number(b.PricingProcedureCounter))
        .filter(element => element.ConditionType === '');
    const product = {
        id: logText(item.Product),
        quantity: logScalar(item.RequestedQuantity),
        unit: { code: logText(item.RequestedQuantitySAPUnit, 16), isoCode: logText(item.RequestedQuantityISOUnit, 16) },
        netAmount: logScalar(item.NetAmount),
        pricingHasError: item.PricingHasError === true,
        mapped,
        priceElementCount: elements.length,
        basePriceAmount: mapped ? logScalar(candidates[0]?.ConditionAmount ?? 0) : null,
        basePriceCandidateCount: candidates.length,
        basePriceCandidates: candidates.slice(0, MAX_BASE_PRICE_CANDIDATES).map(element => ({
            counter: logScalar(element.PricingProcedureCounter, 16),
            amount: logScalar(element.ConditionAmount),
            description: logText(element.PriceElementDescription),
        })),
        basePriceCandidatesOmitted: Math.max(0, candidates.length - MAX_BASE_PRICE_CANDIDATES),
    };
    if (pricingContextDiffers(item, first)) {
        product.contextOverrides = {};
        for (const pair of PRICING_CONTEXT_FIELDS) {
            if (item[pair[0]] !== first?.[pair[0]]) product.contextOverrides[pair[1]] = logScalar(item[pair[0]]);
        }
    }
    return product;
}

function logText(value, limit = 48) {
    if (!['string', 'number', 'boolean'].includes(typeof value)) return '';
    const text = String(value).slice(0, limit);
    let cleaned = '';
    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        cleaned += code < 32 || code === 127 ? ' ' : text[index];
    }
    return cleaned;
}

function logSystemMessage(message) {
    const text = message?.SystemMessageText;
    return {
        type: logText(message?.SystemMessageType, 8),
        class: logText(message?.SystemMessageIdentification),
        number: logText(message?.SystemMessageNumber, 16),
        text: logText(text, MAX_MESSAGE_TEXT_CHARS),
        textTruncated: typeof text === 'string' && text.length > MAX_MESSAGE_TEXT_CHARS,
    };
}

function logPricingSummary(name, summary, maxChars = MAX_LOG_JSON_CHARS) {
    let serialized = JSON.stringify(summary);
    while (serialized.length > maxChars) {
        if (summary.logMode === 'debug') summary.detailsTruncated = true;
        // Keep provider issues ahead of successful/requested product samples.
        if (summary.products.length > 0) {
            summary.products.pop();
            summary.productsOmitted++;
        } else {
            let issue;
            for (let index = summary.issues.length - 1; index >= 0; index--) {
                if (summary.issues[index].messages.length > 1) {
                    issue = summary.issues[index];
                    break;
                }
            }
            if (issue) {
                issue.messages.pop();
                issue.messagesOmitted++;
            } else if (summary.issues.length > 0) {
                summary.issues.pop();
                summary.issuesOmitted++;
            } else {
                // All fields above are bounded, but preserve counts if future
                // additions accidentally exceed the record budget.
                serialized = JSON.stringify({
                    productCount: summary.productCount,
                    mappedProducts: summary.mappedProducts,
                    skippedProducts: summary.skippedProducts,
                    issueProductCount: summary.issueProductCount,
                    systemMessageCount: summary.systemMessageCount,
                    detailsOmitted: true,
                });
                break;
            }
        }
        serialized = JSON.stringify(summary);
    }
    // Diagnostic: <8 KiB. Opt-in debug: <64 KiB. One call in either mode.
    console.log('[' + name + '] ' + serialized);
}

function logPricingContext(input, first) {
    return {
        storeId: logText(input?.commerceContext?.storeId),
        extensionId: logText(input?.extensibilityContext?.id),
        salesOrganization: logText(first?.SalesOrganization, 16),
        distributionChannel: logText(first?.DistributionChannel, 16),
        division: logText(first?.Division, 16),
        currency: logText(first?.TransactionCurrency, 8),
        pricingDate: logText(first?.PricingDate, 32),
    };
}

function logInboundPricing(input, items, priceItems, configuration) {
    const debug = mappingDebugEnabled(input, configuration);
    const productLimit = debug ? MAX_DEBUG_PRODUCT_SAMPLES : MAX_PRODUCT_SAMPLES;
    const issueLimit = debug ? MAX_DEBUG_ISSUE_SAMPLES : MAX_ISSUE_SAMPLES;
    const summary = {
        ...logPricingContext(input, items[0]),
        productCount: items.length,
        mappedProducts: priceItems.length,
        skippedProducts: items.length - priceItems.length,
        issueProductCount: 0,
        systemMessageCount: 0,
        skipReasonCounts: { systemMessages: 0, noPriceElements: 0, nonPositiveNetAmount: 0 },
        products: debug
            ? items.slice(0, productLimit).map(item => logMappingProduct(item, items[0], priceItems.includes(item)))
            : items.slice(0, productLimit).map(item => ({ id: logText(item.Product) })),
        productsOmitted: Math.max(0, items.length - productLimit),
        issues: [],
        issuesOmitted: 0,
    };
    if (debug) {
        summary.logMode = 'debug';
        summary.soldToParty = logText(items[0]?.SoldToParty);
        summary.basePriceSelection = 'firstEmptyConditionTypeByCounter';
        summary.contextMismatchProducts = items.filter(item => pricingContextDiffers(item, items[0])).length;
        summary.detailsTruncated = summary.productsOmitted > 0
            || summary.products.some(product => product.basePriceCandidatesOmitted > 0);
    }
    for (const item of items) {
        const messages = Array.isArray(item._SystemMessages) ? item._SystemMessages : [];
        summary.systemMessageCount += messages.length;
        const reasons = [];
        if (item._SystemMessages?.length > 0) reasons.push('systemMessages');
        if (!(item._SalesPriceElements?.length > 0)) reasons.push('noPriceElements');
        if (!(item.NetAmount > 0)) reasons.push('nonPositiveNetAmount');
        for (const reason of reasons) summary.skipReasonCounts[reason]++;
        if (reasons.length === 0 && item.PricingHasError !== true) continue;
        summary.issueProductCount++;
        if (summary.issues.length >= issueLimit) {
            summary.issuesOmitted++;
            continue;
        }
        summary.issues.push({
            productId: logText(item.Product),
            pricingHasError: item.PricingHasError === true,
            skipped: reasons.length > 0,
            skipReasons: reasons,
            messageCount: messages.length,
            messages: messages.slice(0, MAX_MESSAGE_SAMPLES).map(logSystemMessage),
            messagesOmitted: Math.max(0, messages.length - MAX_MESSAGE_SAMPLES),
        });
    }
    const providerError = input?.data?.error;
    if (providerError) {
        const text = typeof providerError.message === 'string' ? providerError.message : providerError.message?.value;
        summary.providerError = { code: logText(providerError.code), text: logText(text, MAX_MESSAGE_TEXT_CHARS),
            textTruncated: typeof text === 'string' && text.length > MAX_MESSAGE_TEXT_CHARS };
    }
    if (debug) summary.detailsTruncated = summary.detailsTruncated || summary.issuesOmitted > 0
        || summary.issues.some(issue => issue.messagesOmitted > 0 || issue.messages.some(message => message.textTruncated));
    logPricingSummary('s4salespriceInbound', summary, debug ? MAX_DEBUG_JSON_CHARS : MAX_LOG_JSON_CHARS);
}

function logOutboundPricing(input, products, result, configuration) {
    const debug = mappingDebugEnabled(input, configuration);
    const productLimit = debug ? MAX_DEBUG_PRODUCT_SAMPLES : MAX_PRODUCT_SAMPLES;
    const summary = {
        ...logPricingContext(input, result),
        productCount: products.length,
        hasSoldToParty: Boolean(result._SoldToParty?.[0]?.SoldToParty),
        products: products.slice(0, productLimit).map(product => ({
            id: logText(product.id),
            quantity: debug ? logScalar(product.quantity, 16) : logText(product.quantity, 16),
            unit: logText(product.salesMeasureUnit?.code, 16),
            isoUnit: logText(product.salesMeasureUnit?.isoCode, 16),
            ...(debug ? { quantityIncluded: product.quantity != null } : {}),
        })),
        productsOmitted: Math.max(0, products.length - productLimit),
        issues: [],
        issuesOmitted: 0,
    };
    if (debug) {
        summary.logMode = 'debug';
        summary.soldToParty = logText(result._SoldToParty?.[0]?.SoldToParty);
        summary.soldToPartySource = input?.data?.soldToParty ? 'request' : summary.hasSoldToParty ? 'configuration' : 'empty';
        summary.currencySource = input?.data?.currency?.sapCode != null ? 'sapCode' : input?.data?.currency?.code != null ? 'code' : 'empty';
        summary.pricingDateSource = input?.data?.pricingAt ? 'pricingAt' : 'currentDate';
        summary.detailsTruncated = summary.productsOmitted > 0;
    }
    logPricingSummary('s4salespriceOutbound', summary, debug ? MAX_DEBUG_JSON_CHARS : MAX_LOG_JSON_CHARS);
}

export const handler = (input, configuration) => {
    const data = input?.data ?? {};
    const configMap = (configuration && typeof configuration === "object") ? configuration : {};
    const storeId = input?.commerceContext?.storeId?.trim() ?? "";
    const prefix = `${storeId}.`;
    const configuredSoldToParty = configMap[`${prefix}one-time.customer.id`]?.trim() ?? "";

    const {
        products = [],
        currency = {},
        soldToParty = "",
        salesArea = {},
        pricingAt = ""
    } = data;

    const pricingDate = pricingAt ? pricingAt.split('T')[0] : new Date().toISOString().split('T')[0];

    const result = {
        SalesOrganization: salesArea.salesOrganization ?? "",
        DistributionChannel: salesArea.distributionChannel ?? "",
        Division: salesArea.division ?? "",
        TransactionCurrency: currency.sapCode ?? currency.code ?? "",
        LanguageISOCode: "",
        SalesDocumentType: "",
        SalesDocumentItemCategory: "",
        BillingDocumentType: "",
        SalesPriceRetrieveUseCase: "SAP_DFLT",
        PriceElementsAreRequested: true,
        PricingDate: pricingDate,
        _Product: products.map(p => ({
            Product: p.id,
            ProductUsedByCustomer: "",
            ...(p.quantity != null && {
                RequestedQuantity: p.quantity,
                RequestedQuantityISOUnit: p.salesMeasureUnit?.isoCode ?? "",
                RequestedQuantitySAPUnit: p.salesMeasureUnit?.code ?? ""
            }),
        })),
        _SoldToParty: [{SoldToParty: soldToParty || configuredSoldToParty}]
    };
    logOutboundPricing(input, products, result, configuration);
    return result;
};
